import { PublicService } from 'src/app/_Service/public.service';
import { Coupon } from 'src/app/_Models/coupon.model';
import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';


@Component({
  selector: 'app-list-perchase-coupons',
  templateUrl: './list-perchase-coupons.component.html',
  styleUrls: ['./list-perchase-coupons.component.css']
})
export class ListPerchaseCouponsComponent implements OnInit {

  coupons: Coupon[] = [];
  totalCoups: number;
  flag = false;
  couponId: number;
  coupon: Coupon = new Coupon();
  byId = true;
  type = false;
  price = false;
  date = false;


  constructor(private publicService: PublicService) { }

  ngOnInit() {
    const observable: Observable<Coupon[]> = this.publicService.getAllCoupons;
    observable.subscribe(coupons => {this.coupons = coupons;
      this.totalCoups = coupons.length;});
    }

  onGetAll(){
    const observable: Observable<Coupon[]> = this.publicService.getAllCoupons;
    observable.subscribe(coupons => { this.coupons = coupons;
      this.totalCoups = coupons.length;});
    }

  onSearch(){
    if(this.byId){
      this.coupons = [];
      let couponId: number = (<HTMLInputElement> document.getElementById("couponId")).valueAsNumber;
      const observable: Observable<Coupon> = this.publicService.getCouponById(couponId);
      observable.subscribe(coupon => this.coupons.push(coupon));
      alert(`number =` + couponId);
    }else if (this.type){
      let couponType = (<HTMLInputElement> document.getElementById("CouponType")).value;
      const observable: Observable<Coupon[]> = this.publicService.getAllCouponsByType(couponType);
      observable.subscribe(coupons => this.coupons = coupons);
      alert(`type =` + couponType);
    }else if (this.price ) {
      let couponPrice: number = (<HTMLInputElement> document.getElementById("couponPrice")).valueAsNumber;
      const observable: Observable<Coupon[]> = this.publicService.getAllCouponsByPrice(couponPrice);
      observable.subscribe(coupons => this.coupons = coupons);
    }else{
      let couponDate: Date = (<HTMLInputElement> document.getElementById("couponDate")).valueAsDate;
      const observable: Observable<Coupon[]> = this.publicService.getAllCouponsByDate(couponDate);
      observable.subscribe(coupons => this.coupons = coupons);
    }
  }
  onById(){
    this.byId = true;
    this.type = false;
    this.price = false;
    this.date = false;
  }

  onType(){
  this.byId = false;
  this.type = true;
  this.price = false;
  this.date = false;
  }

  onPrice(){
    this.byId = false;
    this.type = false;
    this.price = true;
    this.date = false;
  }

  onDate(){
    this.byId = false;
    this.type = false;
    this.price = false;
    this.date = true;
  }

}
