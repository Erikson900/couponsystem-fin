import { CustomerService } from './../../../_Service/customer.service';
import { Component, Input } from '@angular/core';
import { Coupon } from 'src/app/_Models/coupon.model';

@Component({
  selector: 'app-coupon',
  templateUrl: './coupon.component.html',
  styleUrls: ['./coupon.component.css']
})
export class CouponComponent  {

  @Input() coupon: Coupon = new Coupon;
  @Input() index: number;

  detail = false;

  constructor(private customerService: CustomerService) { }

  public perchacedCoupon: Coupon;

  onPerchase(){
    this.perchacedCoupon = this.coupon;
    this.customerService.perchase(this.perchacedCoupon).subscribe( Coupon => {
      console.log(Coupon);
    }, err => {
      alert(err.massage);
    })
  }

  onDetail(){
    this.detail = !this.detail;
  }
}
