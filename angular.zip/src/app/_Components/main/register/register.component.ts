import { PublicService } from 'src/app/_Service/public.service';
import { Company } from 'src/app/_Models/company.model';
import { Component, OnInit } from '@angular/core';
import { Customer } from 'src/app/_Models/customer.model';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

customerC: Customer = new Customer();
companyC: Company = new Company();

ConfirmPassword: string;
customer = false;
company = false;

  constructor(private publicService: PublicService) { }

  ngOnInit() {
  }

  newCustomer() {
    this.customer = true;
    this.company = false;
    //return this.customer = new Customer(customer);
  }

  newCompany() {
    this.customer = false;
    this.company = true;
    //return this.company = new Company(company);
  }

  public createCUstomer() {
    alert(`
    CustomerName: ${this.customerC.custName}
    CustomerPassword: ${this.customerC.password}
    `);


    this.publicService.createCustomer(this.customerC).subscribe( customer => {
      this.customerC = customer;
      console.log(customer); }, err => {
        alert(err.massage);
    });
  }

  public createCompany(){
    alert(`
    CompanyName: ${this.companyC.compName}
    CompanyPassword: ${this.companyC.password}
    CompanyEmail: ${this.companyC.email}
    `);


    this.publicService.createComp(this.companyC).subscribe( company => {
      this.companyC = company;
      console.log(company);}, err => {
        alert(err.massage);
    })
  }

}
