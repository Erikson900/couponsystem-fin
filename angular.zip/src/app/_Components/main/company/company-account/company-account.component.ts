
import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/_Service/auth.service';
import { AdminService } from 'src/app/_Service/admin.service';
import { Company } from 'src/app/_Models/company.model';

@Component({
  selector: 'app-company-account',
  templateUrl: './company-account.component.html',
  styleUrls: ['./company-account.component.css']
})
export class CompanyAccountComponent implements OnInit {

  company: Company = new Company();

  edit = false;


  constructor(private authService: AuthService,private adminService: AdminService) { }



  ngOnInit() {
    const observable = this.adminService.getCompById(this.authService.getLoggedUser().id);
    observable.subscribe(company => this.company = company);
  }

  onEdit(company: Company) {
    this.edit = true;
    this.adminService.startedEdeting.next(company);
  }

  onCancel(){
    this.edit = false;
  }

}
