import { Coupon } from 'src/app/_Models/coupon.model';
import { CompanyService } from './../../../../_Service/company.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-coupon-new',
  templateUrl: './coupon-new.component.html',
  styleUrls: ['./coupon-new.component.css']
})
export class CouponNewComponent implements OnInit {

  constructor(private companyService: CompanyService) { }

  public coupon: Coupon = new Coupon();

  ngOnInit() {
  }

  public createCoupon(){
    alert(`
    CouponTitle: ${this.coupon.title}
    CouponPrice: ${this.coupon.price}
    CouponAmount: ${this.coupon.amount}
    CouponStartDate: ${this.coupon.startDate}
    CouponEndDate: ${this.coupon.endDate}
    CouponMessage: ${this.coupon.message}
    CouponImageUrl: ${this.coupon.image}
    CouponType: ${this.coupon.couponType}
    `);


    this.companyService.createCoupon(this.coupon).subscribe( coupon => {
      this.coupon = coupon;
      console.log(coupon);}, err => {
        alert(err.massage);
    })
  }
}
