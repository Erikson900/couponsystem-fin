import { CompanyService } from 'src/app/_Service/company.service';
import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Subscription } from 'rxjs';
import { Coupon } from 'src/app/_Models/coupon.model';

@Component({
  selector: 'app-coupon-edit',
  templateUrl: './coupon-edit.component.html',
  styleUrls: ['./coupon-edit.component.css']
})
export class CouponEditComponent implements OnInit {

  @ViewChild('f') CustomerListForm: NgForm;
  subscription: Subscription;
  coupon: Coupon = new Coupon();


  constructor(private compService: CompanyService) { }

  ngOnInit() {
    this.subscription = this.compService.startedEdetingCoupon
    .subscribe(
      (coupon: Coupon) => {
        this.coupon = coupon;
    });
  }

  onUpdate() {
    this.coupon.id = (document.getElementById('id') as HTMLInputElement).valueAsNumber;
    this.coupon.title = (document.getElementById('title') as HTMLInputElement).value;
    this.coupon.startDate = (document.getElementById('startDate') as HTMLInputElement).valueAsDate;
    this.coupon.endDate = (document.getElementById('endDate') as HTMLInputElement).valueAsDate;
    this.coupon.amount = (document.getElementById('amount') as HTMLInputElement).valueAsNumber;
    this.coupon.message = (document.getElementById('message') as HTMLInputElement).value;
    this.coupon.price = (document.getElementById('price') as HTMLInputElement).valueAsNumber;
    this.coupon.image = (document.getElementById('image') as HTMLInputElement).value;



    this.compService.updateCoupon(this.coupon).subscribe( coupon => {
      this.coupon = coupon;
      console.log(coupon); }, err => {
        alert(err.error.massage);
    });
  }
}
