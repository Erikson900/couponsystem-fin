import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/_Service/auth.service';
import { Router } from '@angular/router';
import { User, ClientType } from 'src/app/_Models/user.model';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {


  ngOnInit(): void {

  }


  public user: User = new User();

  constructor(private authService: AuthService,private router: Router) { }
  public login() {
    alert(`user Name=${this.user.userName}
    password=${this.user.password}
    client Type=${this.user.clientType}`);

    this.authService.login(this.user).subscribe(user => {
    this.user = user;


    if (user.clientType === ClientType.ADMIN) {
      alert(`Admin is in`)
      this.authService.loggedUser(this.user);
      this.router.navigate(['admin']);
    } else if (user.clientType === ClientType.COMPANY) {
      this.authService.loggedUser(this.user);
      alert(`Company is in`)
      this.router.navigate(['company']);
    } else if (user.clientType === ClientType.CUSTOMER) {
      this.authService.loggedUser(this.user);
      alert(`Customer is in`)
      this.router.navigate(['customer']);
    }
    console.log(user);

  }, err => {
    alert(err.error.message);
  });
  }
}
