import { Component, OnInit } from '@angular/core';
import { AdminService } from 'src/app/_Service/admin.service';
import { Customer } from 'src/app/_Models/customer.model';


@Component({
  selector: 'app-customers-list',
  templateUrl: './customers-list.component.html',
  styleUrls: ['./customers-list.component.css']
})
export class CustomersListComponent implements OnInit {

  customers: Customer[];
  flag = false;
  custId: number;
  customer: Customer = new Customer();
  totalCusts: number;

  create = false;

  edit = false;

  constructor(private adminService: AdminService) { }

  ngOnInit() {
    const observable = this.adminService.getAllCustomers;
    observable.subscribe(customers => {this.customers = customers;
      this.totalCusts = customers.length;});
  }

  createCUstomer(){
    this.create = !this.create;
    this.edit = false;
  }

  onEdit(customer: Customer) {
    this.edit = true;
    this.create = false;
    this.adminService.startedEdetingCust.next(customer);
  }

  onCancel(){
    this.edit =false;
    this.create = false;
  }

  onDelete(custId: number){
    if(confirm("the folowing action will delete the customer and all of his coupons /n are you sure you want to"
    + "proceed ?")){
    this.adminService.removeCustomer(custId).subscribe( flag => {
      this.flag = flag;
      console.log(this.flag);
    }, err => {
      alert(err.massage);
    });
    alert(`custId = ` + custId)
    this.ngOnInit();
  }else{
    this.ngOnInit();
  }
  }

  onGetById(){
    this.adminService.geCustomerById(this.custId).subscribe( Customer => {
    this.customer = Customer;
    this.flag = true;
    this.customers = [];
    this.customers.push(this.customer);
    console.log(Customer);

    }, err => {
      alert(err.massage);
    });
  }

}


