import { AdminService } from 'src/app/_Service/admin.service';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Company } from 'src/app/_Models/company.model';
import { ActivatedRoute, Router } from '@angular/router';


@Component({
  selector: 'app-companys-list',
  templateUrl: './companys-list.component.html',
  styleUrls: ['./companys-list.component.css']
})
export class CompanysListComponent implements OnInit, OnDestroy {

  companies: Company[] = [];
  flag = false;
  companyid: number;
  company: Company = new Company();
  totalComps: number;

  create = false;

  edit = false;

  constructor(private adminService: AdminService, private route: ActivatedRoute, private router: Router) { }

  ngOnInit() {
    const observable = this.adminService.getAllComps;
    observable.subscribe(companies => {this.companies = companies;
                                       this.totalComps = companies.length; });
  }

  newCompany() {
    this.create = !this.create;
    this.edit = false;
  }

  onEdit(company: Company) {
    this.adminService.startedEdeting.next(company);
    this.edit = true;
    this.create = false;
  }

  onCancel() {
    this.edit = false;
    this.create = false;
  }

  onDelete(compId: number) {
    if (confirm('the folowing action will delete the company and all it\'s coupons /n are you sure you want to'
    + 'proceed ?')) {
    this.adminService.removeComp(compId).subscribe( flag => {
      this.flag = flag;
      console.log(this.flag);
    }, err => {
      alert(err.massage);
    });
    alert(`compId = ` + compId);
    this.ngOnInit();
  } else {
    this.ngOnInit();
  }
  }

  onGetById() {
    this.adminService.getCompById(this.companyid).subscribe( Company => {
    this.company = Company;
    this.flag = true;
    this.companies = [];
    this.companies.push(this.company);
    console.log(Company);

    }, err => {
      alert(err.massage);
    });
  }

  ngOnDestroy(): void {
  this.adminService.startedEdeting.unsubscribe;
  }

}
