import { Component, OnInit } from '@angular/core';
import { Customer } from 'src/app/_Models/customer.model';
import { AdminService } from 'src/app/_Service/admin.service';

@Component({
  selector: 'app-customer-new',
  templateUrl: './customer-new.component.html',
  styleUrls: ['./customer-new.component.css']
})
export class CustomerNewComponent implements OnInit {

  customer: Customer = new Customer();

  constructor(private adminService: AdminService) { }

  ngOnInit() {
  }

  public createCUstomer() {
    this.customer.custName = (<HTMLInputElement> document.getElementById("custName")).value;
    this.customer.password = (<HTMLInputElement> document.getElementById("password")).value;
  
    alert(`
    CustomerName: ${this.customer.custName}
    CustomerPassword: ${this.customer.password}
    `);


    this.adminService.createCustomer(this.customer).subscribe( customer => {
      this.customer = customer;
      console.log(customer); }, err => {
        alert(err.massage);
    });
  }

}
