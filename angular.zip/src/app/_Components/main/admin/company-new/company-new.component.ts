import { Company } from 'src/app/_Models/company.model';
import { Component, OnInit } from '@angular/core';
import { AdminService } from 'src/app/_Service/admin.service';

@Component({
  selector: 'app-company-new',
  templateUrl: './company-new.component.html',
  styleUrls: ['./company-new.component.css']
})
export class CompanyNewComponent implements OnInit {

  public company: Company = new Company();

  constructor(private adminService: AdminService) { }

  ngOnInit() {
  }

  public createCompany(){
    this.company.compName = (<HTMLInputElement> document.getElementById("compName")).value;
    this.company.password = (<HTMLInputElement> document.getElementById("password")).value;
    this.company.email = (<HTMLInputElement> document.getElementById("email")).value;

    alert(`
    CompanyName: ${this.company.compName}
    CompanyPassword: ${this.company.password}
    CompanyEmail: ${this.company.email}
    `);


    this.adminService.createComp(this.company).subscribe( company => {
      this.company = company;
      console.log(company);}, err => {
        alert(err.massage);
    })
  }

}
