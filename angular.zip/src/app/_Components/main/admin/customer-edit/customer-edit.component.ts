import { Customer } from 'src/app/_Models/customer.model';
import { Component,ViewChild, OnInit } from '@angular/core';
import { AdminService } from 'src/app/_Service/admin.service';
import { NgForm} from '@angular/forms';
import { Subscription } from 'rxjs/internal/Subscription';

@Component({
  selector: 'app-customer-edit',
  templateUrl: './customer-edit.component.html',
  styleUrls: ['./customer-edit.component.css']
})
export class CustomerEditComponent implements OnInit {
  @ViewChild('f') CustomerListForm: NgForm;
  subscription: Subscription;
  customer: Customer = new Customer();

  constructor(private adminService: AdminService) { }

  ngOnInit() {
    this.subscription = this.adminService.startedEdetingCust
    .subscribe(
      (customer: Customer) => {
        this.customer = customer;
    });
  }

  onUpdate(){
    this.customer.custId = (<HTMLInputElement> document.getElementById("id")).valueAsNumber;
    this.customer.custName = (<HTMLInputElement> document.getElementById("custName")).value;
    this.customer.password = (<HTMLInputElement> document.getElementById("password")).value;
  

    this.adminService.updateCustomer(this.customer).subscribe( customer => {
      this.customer = customer;
      console.log(customer);}, err => {
        alert(err.massage);
    })
  }

}
