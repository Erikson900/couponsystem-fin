import { CustomerService } from 'src/app/_Service/customer.service';
import { Component, OnInit, } from '@angular/core';
import { Coupon } from 'src/app/_Models/coupon.model';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-perchased-coupons',
  templateUrl: './perchased-coupons.component.html',
  styleUrls: ['./perchased-coupons.component.css']
})
export class PerchasedCouponsComponent implements OnInit {

  coupons: Coupon[] = [];
  flag = false;
  couponId: number;
  coupon: Coupon = new Coupon();
  byId = true;
  type = false;
  price = false;
  date = false;

  constructor(private custService: CustomerService) { }

  ngOnInit() {
    const observable: Observable<Coupon[]> = this.custService.getAllPerchasedCoupons;
    observable.subscribe(coupons => this.coupons = coupons);
  }

  onDelete(couponId: number){
    this.custService.removeCoupon(couponId).subscribe( flag => {
      this.flag = flag;
      console.log(this.flag);
    }, err => {
      alert(err.massage);
    });
    alert(`couponId = ` + couponId)
    this.ngOnInit();
  }

  onGetAll(){
    const observable: Observable<Coupon[]> = this.custService.getAllPerchasedCoupons;
    observable.subscribe(coupons => this.coupons = coupons);
  }

  onSearch(){
    if(this.byId){
      this.coupons = [];
      let couponId: number = (<HTMLInputElement> document.getElementById("couponId3")).valueAsNumber;
      const observable: Observable<Coupon> = this.custService.getPerchasedCouponById(couponId);
      observable.subscribe(coupon => this.coupons.push(coupon));
    }else if (this.type){
      let couponType = (<HTMLInputElement> document.getElementById("CouponType3")).value;
      const observable: Observable<Coupon[]> = this.custService.getPurchasedCouponsByType(couponType);
      observable.subscribe(coupons => this.coupons = coupons);
    }else if (this.price ) {
      let couponPrice: number = (<HTMLInputElement> document.getElementById("couponPrice3")).valueAsNumber;
      const observable: Observable<Coupon[]> = this.custService.getPurchaedCouponsByPrice(couponPrice);
      observable.subscribe(coupons => this.coupons = coupons);
    }else{
      let couponDate: Date = (<HTMLInputElement> document.getElementById("couponDate3")).valueAsDate;
      const observable: Observable<Coupon[]> = this.custService.getPurchaedCouponsByDate(couponDate);
      observable.subscribe(coupons => this.coupons = coupons);
    }
  }
  onById(){
    this.byId = true;
    this.type = false;
    this.price = false;
    this.date = false;
  }

  onType(){
  this.byId = false;
  this.type = true;
  this.price = false;
  this.date = false;
  }

  onPrice(){
    this.byId = false;
    this.type = false;
    this.price = true;
    this.date = false;
  }

  onDate(){
    this.byId = false;
    this.type = false;
    this.price = false;
    this.date = true;
  }

}
