import { AdminService } from 'src/app/_Service/admin.service';
import { AuthService } from 'src/app/_Service/auth.service';
import { Component, OnInit } from '@angular/core';
import { Customer } from 'src/app/_Models/customer.model';

@Component({
  selector: 'app-customer-account',
  templateUrl: './customer-account.component.html',
  styleUrls: ['./customer-account.component.css']
})
export class CustomerAccountComponent implements OnInit {

  customer: Customer = new Customer();

  edit = false;


  constructor(private authService: AuthService,private adminService: AdminService) { }



  ngOnInit() {
    const observable = this.adminService.geCustomerById(this.authService.getLoggedUser().id);
    observable.subscribe(customer => this.customer = customer);
  }

  onEdit(customer: Customer) {
    this.edit = true;
    this.adminService.startedEdetingCust.next(customer);
  }

  onCancel(){
    this.edit = false;
  }

}
