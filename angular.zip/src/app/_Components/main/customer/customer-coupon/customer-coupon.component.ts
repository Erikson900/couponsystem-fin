import { Component, OnInit, Input } from '@angular/core';
import { Coupon } from 'src/app/_Models/coupon.model';

@Component({
  selector: 'app-customer-coupon',
  templateUrl: './customer-coupon.component.html',
  styleUrls: ['./customer-coupon.component.css']
})
export class CustomerCouponComponent implements OnInit {

  @Input() coupon: Coupon;
  @Input() index: number;

  constructor() { }

  ngOnInit() {
  }

}
