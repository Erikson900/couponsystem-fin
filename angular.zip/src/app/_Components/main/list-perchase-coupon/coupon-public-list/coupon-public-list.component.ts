import { Component, OnInit } from '@angular/core';
import { Coupon } from 'src/app/_Models/coupon.model';
import { PublicService } from 'src/app/_Service/public.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-coupon-public-list',
  templateUrl: './coupon-public-list.component.html',
  styleUrls: ['./coupon-public-list.component.css']
})
export class CouponPublicListComponent implements OnInit {

  coupons: Coupon[] = [];
  totalCoups: number;
  flag = false;
  couponId: number;
  coupon: Coupon = new Coupon();
  byId = true;
  type = false;
  price = false;
  date = false;


  constructor(private publicService: PublicService) { }

  ngOnInit() {
    const observable: Observable<Coupon[]> = this.publicService.getAllCoupons;
    observable.subscribe(coupons => {this.coupons = coupons;
                                    this.totalCoups = coupons.length; });
    }

  onGetAll() {
    const observable: Observable<Coupon[]> = this.publicService.getAllCoupons;
    observable.subscribe(coupons => { this.coupons = coupons;
                                      this.totalCoups = coupons.length; });
    }

  onSearch() {
    if (this.byId) {
      this.coupons = [];
      const couponId: number = (document.getElementById('couponId') as HTMLInputElement).valueAsNumber;
      const observable: Observable<Coupon> = this.publicService.getCouponById(couponId);
      observable.subscribe(coupon => this.coupons.push(coupon));
      alert(`number =` + couponId);
    } else if (this.type) {
      const couponType = (document.getElementById('CouponType') as HTMLInputElement).value;
      const observable: Observable<Coupon[]> = this.publicService.getAllCouponsByType(couponType);
      observable.subscribe(coupons => this.coupons = coupons);
      alert(`type =` + couponType);
    } else if (this.price ) {
      const couponPrice: number = (document.getElementById('couponPrice') as HTMLInputElement).valueAsNumber;
      const observable: Observable<Coupon[]> = this.publicService.getAllCouponsByPrice(couponPrice);
      observable.subscribe(coupons => this.coupons = coupons);
    } else {
      const couponDate: Date = (document.getElementById('couponDate') as HTMLInputElement).valueAsDate;
      const observable: Observable<Coupon[]> = this.publicService.getAllCouponsByDate(couponDate);
      observable.subscribe(coupons => this.coupons = coupons);
    }
  }
  onById() {
    this.byId = true;
    this.type = false;
    this.price = false;
    this.date = false;
  }

  onType() {
  this.byId = false;
  this.type = true;
  this.price = false;
  this.date = false;
  }

  onPrice() {
    this.byId = false;
    this.type = false;
    this.price = true;
    this.date = false;
  }

  onDate() {
    this.byId = false;
    this.type = false;
    this.price = false;
    this.date = true;
  }

}
