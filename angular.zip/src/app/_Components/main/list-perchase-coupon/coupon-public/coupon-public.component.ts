import { Component, OnInit, Input } from '@angular/core';
import { Coupon } from 'src/app/_Models/coupon.model';

@Component({
  selector: 'app-coupon-public',
  templateUrl: './coupon-public.component.html',
  styleUrls: ['./coupon-public.component.css']
})
export class CouponPublicComponent implements OnInit {

  constructor() { }

  @Input() coupon: Coupon = new Coupon;
  @Input() index: number;

  detail = false;

  ngOnInit(): void {
  }


  onDetail(){
    this.detail = !this.detail;
  }
}
