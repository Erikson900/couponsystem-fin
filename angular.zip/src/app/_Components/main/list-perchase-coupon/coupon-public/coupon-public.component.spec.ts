import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CouponPublicComponent } from './coupon-public.component';

describe('CouponPublicComponent', () => {
  let component: CouponPublicComponent;
  let fixture: ComponentFixture<CouponPublicComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CouponPublicComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CouponPublicComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
