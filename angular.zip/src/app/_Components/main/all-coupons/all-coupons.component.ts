import { CompanyService } from 'src/app/_Service/company.service';
import { Observable } from 'rxjs';
import { Component, OnInit } from '@angular/core';
import { Coupon } from 'src/app/_Models/coupon.model';

@Component({
  selector: 'app-all-coupons',
  templateUrl: './all-coupons.component.html',
  styleUrls: ['./all-coupons.component.css']
})
export class AllCouponsComponent {

  coupons: Coupon[] = [];
  flag = false;
  couponId: number;
  coupon: Coupon = new Coupon();
  totalCoups: number;

  byId = true;
  type = false;
  price = false;
  date = false;

  create = false;

  edit = false;

  constructor(private compService:CompanyService) {
  }


  ngOnInit() {
    const observable: Observable<Coupon[]> = this.compService.getAllCompanyCoupons;
    observable.subscribe(coupons => {this.coupons = coupons;
    this.totalCoups = coupons.length;});
  }

  onEdit(coupon: Coupon) {console.log("BLha1");
    const coupon1: Coupon = coupon;
    this.edit = true;
    this.create = false;
    this.compService.startedEdetingCoupon.next(coupon1);
    console.log("BLha2");
  }

  onCancel(){
    this.edit = false;
  }

  onDelete(couponId: number){
    if(confirm("the folowing action will delete the Coupon are you sure you want to"
    + " proceed ?")){
    this.compService.removeCoupon(couponId).subscribe( flag => {
      this.flag = flag;
      console.log(this.flag);
    }, err => {
      alert(err.massage);
    });
    alert(`couponId = ` + couponId)
    this.ngOnInit();
  }else{
    this.ngOnInit();
  }
  }

  onGetAll(){
    const observable: Observable<Coupon[]> = this.compService.getAllCompanyCoupons;
    observable.subscribe(coupons => {this.coupons = coupons;
    this.totalCoups = coupons.length;});
  }

  onSearch(){
    if(this.byId){
      this.coupons = [];
      let couponId: number = (<HTMLInputElement> document.getElementById("couponId")).valueAsNumber;
      const observable: Observable<Coupon> = this.compService.getCouponById(couponId);
      observable.subscribe(coupon => this.coupons.push(coupon));
    }else if (this.type){
      let couponType = (<HTMLInputElement> document.getElementById("CouponType")).value;
      const observable: Observable<Coupon[]> = this.compService.getAllCompanyCouponsByType(couponType);
      observable.subscribe(coupons => this.coupons = coupons);
    }else if (this.price ) {
      let couponPrice: number = (<HTMLInputElement> document.getElementById("couponPrice")).valueAsNumber;
      const observable: Observable<Coupon[]> = this.compService.getAllCompanyCouponsByPrice(couponPrice);
      observable.subscribe(coupons => this.coupons = coupons);
    }else{
      let couponDate: Date = (<HTMLInputElement> document.getElementById("couponDate")).valueAsDate;
      const observable: Observable<Coupon[]> = this.compService.getAllCompanyCouponsByDate(couponDate);
      observable.subscribe(coupons => this.coupons = coupons);
    }
  }
  onById(){
    this.byId = true;
    this.type = false;
    this.price = false;
    this.date = false;
  }

  onType(){
  this.byId = false;
  this.type = true;
  this.price = false;
  this.date = false;
  }

  onPrice(){
    this.byId = false;
    this.type = false;
    this.price = true;
    this.date = false;
  }

  onDate(){
    this.byId = false;
    this.type = false;
    this.price = false;
    this.date = true;
  }

  newCoupon(){
    this.create = !this.create;
    this.edit = false;
  }


}
