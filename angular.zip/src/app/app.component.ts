import { Component } from '@angular/core';
import { Subscription } from 'rxjs';
import { User, ClientType } from './_Models/user.model';
import { AuthService } from './_Service/auth.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'CouponSystem';


  subscription: Subscription;
  user: User = new User();
  public = true;
  admin = false;
  company = false;
  customer = false;

  constructor(private authService: AuthService) { }

  ngOnInit() {
    this.user = this.authService.getLoggedUser();
    if (this.user.clientType === ClientType.ADMIN && this.user.userName != null) {
      this.public = false;
      this.admin = true;
      this.company = false;
      this.customer = false;
    } else if (this.user.clientType === ClientType.COMPANY && this.user.userName != null ) {
      this.public = false;
      this.admin = false;
      this.company = true;
      this.customer = false;
    } else if (this.user.clientType === ClientType.CUSTOMER && this.user.userName != null ) {
      this.public = false;
      this.admin = false;
      this.company = false;
      this.customer = true;
    } else {
      this.public = true;
      this.admin = false;
      this.company = false;
      this.customer = false;
    }
  }


}
