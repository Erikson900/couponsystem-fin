import { CouponType } from 'src/app/_Models/coupon.model';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Coupon } from '../_Models/coupon.model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

//public coupon1: Coupon = new Coupon();

  constructor(private httpClient: HttpClient) { }

  public perchase(coupon: Coupon): Observable<Coupon> {
    alert(`Coup id =${coupon.id}
    Coup name =${coupon.title}
    Coup start =${coupon.startDate}
    Coup end =${coupon.endDate}
    Coup price=${coupon.price}
    Coup type =${coupon.couponType}
    Coup amount =${coupon.amount}`);

    return this.httpClient.post<Coupon>('http://localhost:8080/Customer/purchase', coupon, {withCredentials: true});
  }

  public removeCoupon(couponId: number): Observable<boolean> {
    return this.httpClient.delete<boolean>('http://localhost:8080/Customer/removeCoupon/' + couponId, {withCredentials: true});
  }

  public getPerchasedCouponById(coupId: number): Observable<Coupon> {
    return this.httpClient.get<Coupon>('http://localhost:8080/Customer/getCoupon/' + coupId, {withCredentials: true});
  }

  public get getAllPerchasedCoupons(): Observable<Coupon[]> {
    return this.httpClient.get<Coupon[]>('http://localhost:8080/Customer/allPerchasedCoupons', {withCredentials: true});
  }

  public getPurchasedCouponsByType(type: string): Observable<Coupon[]> {
    return this.httpClient.get<Coupon[]>('http://localhost:8080/Customer/byType/' + type, {withCredentials: true});
  }

  public getPurchaedCouponsByPrice(price: number): Observable<Coupon[]> {
    return this.httpClient.get<Coupon[]>('http://localhost:8080/Customer/byPrice/' + price, {withCredentials: true});
  }

  public getPurchaedCouponsByDate(date: Date): Observable<Coupon[]> {
    return this.httpClient.get<Coupon[]>('http://localhost:8080/Customer/date/' + date, {withCredentials: true});
  }
}
