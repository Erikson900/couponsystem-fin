import { CouponType } from 'src/app/_Models/coupon.model';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { Coupon } from '../_Models/coupon.model';

@Injectable({
  providedIn: 'root'
})
export class CompanyService {

  startedEdetingCoupon = new Subject<Coupon>();

  constructor(private httpClient: HttpClient) { }

  public createCoupon(coupon: Coupon): Observable<Coupon> {
    return this.httpClient.post<Coupon>('http://localhost:8080/Company/createCoupon', coupon, {withCredentials: true});
  }

  public removeCoupon(couponId: number): Observable<boolean> {
    return this.httpClient.delete<boolean>('http://localhost:8080/Company/removeCoupon/' + couponId, {withCredentials: true});

  }

  public updateCoupon(coupon: Coupon): Observable<Coupon> {
    return this.httpClient.put<Coupon>('http://localhost:8080/Company/updateCoupon', coupon, {withCredentials: true});
  }

  public getCouponById(couponId: number): Observable<Coupon> {
    return this.httpClient.get<Coupon>('http://localhost:8080/Company/getCoupon/' + couponId, {withCredentials: true});
  }

  public get getAllCompanyCoupons(): Observable<Coupon[]> {
    return this.httpClient.get<Coupon[]>('http://localhost:8080/Company/allCompanyCoupons/', {withCredentials: true});
  }

  public getAllCompanyCouponsByType(type: string): Observable<Coupon[]> {
    return this.httpClient.get<Coupon[]>('http://localhost:8080/Company/allCompanyCouponsByType/' + type, {withCredentials: true});
  }

  public getAllCompanyCouponsByPrice(price: number): Observable<Coupon[]> {
    return this.httpClient.get<Coupon[]>('http://localhost:8080/Company/allCompanyCouponsByPrice/' + price, {withCredentials: true});
  }

  public getAllCompanyCouponsByDate(date: Date): Observable<Coupon[]> {
    return this.httpClient.get<Coupon[]>('http://localhost:8080/Company/allCompanyCouponsByDate/' + date, {withCredentials: true});
  }

}
