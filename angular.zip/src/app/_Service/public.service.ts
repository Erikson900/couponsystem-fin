import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Coupon } from '../_Models/coupon.model';
import { Observable } from 'rxjs';
import { Customer } from '../_Models/customer.model';
import { Company } from '../_Models/company.model';

@Injectable({
  providedIn: 'root'
})
export class PublicService {

  httpGetOptions = { withCredentials: true, };

  constructor(private httpClient: HttpClient) { }

  public createCustomer(customer: Customer): Observable<Customer> {
    return this.httpClient.post<Customer>('http://localhost:8080/Admin/creatCustomer', customer, {withCredentials: true});
  }

  public createComp(company: Company): Observable<Company> {
    return this.httpClient.post<Company>('http://localhost:8080/Admin/createCompany', company, {withCredentials: true});
  }

  public get getAllCoupons(): Observable<Coupon[]> {
    return this.httpClient.get<Coupon[]>('http://localhost:8080/Public/allCoupons', this.httpGetOptions);
  }

  public getCouponById(id: number): Observable<Coupon> {
    return this.httpClient.get<Coupon>('http://localhost:8080/Public/getCoupon/' + id, {withCredentials: true});
  }

  public getAllCouponsByType(type: string): Observable<Coupon[]> {
    return this.httpClient.get<Coupon[]>('http://localhost:8080/Public/allCouponsByType/' + type, {withCredentials: true});
  }

  public getAllCouponsByPrice(price: number): Observable<Coupon[]> {
    alert(`Blat = ` + price);
    return this.httpClient.get<Coupon[]>('http://localhost:8080/Public/allCouponsByPrice/' + price, {withCredentials: true});
  }

  public getAllCouponsByDate(date: Date): Observable<Coupon[]> {
    return this.httpClient.get<Coupon[]>('http://localhost:8080/Public/allCouponsByDate/' + date, {withCredentials: true});
  }

}
