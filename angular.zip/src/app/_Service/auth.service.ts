import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from '../_Models/user.model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private user: User = new User();

  constructor(private httpClient: HttpClient,) {

  }

  public login(user: User): Observable<User> {
    return this.httpClient.post<User>('http://localhost:8080/Login', user, {withCredentials: true});
  }

  public loggedUser(user: User) {
    this.user = user;
  }

  public getLoggedUser(): User {
    return this.user;
  }

  public logout(): Observable<boolean>{
    return this.httpClient.post<boolean>('http://localhost:8080/Login/logout', {withCredentials: true});
  }

}
