import { CompanysListComponent } from 'src/app/_Components/main/admin/companys-list/companys-list.component';
import { Customer } from './../_Models/customer.model';
import { Company } from './../_Models/company.model';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  startedEdeting = new Subject<Company>();
  startedEdetingCust = new Subject<Customer>();

  onCancel = false;


  constructor(private httpClient: HttpClient ) { }

  public createComp(company: Company): Observable<Company> {
    return this.httpClient.post<Company>('http://localhost:8080/Admin/createCompany', company, {withCredentials: true});
  }

  public updateComp(company: Company) {
    return this.httpClient.put('http://localhost:8080/Admin/updateCompany', company, {withCredentials: true});
  }

  public removeComp(compId: number): Observable<boolean> {
    return  this.httpClient.delete<boolean>('http://localhost:8080/Admin/removeComp/' + compId, {withCredentials: true});
    alert(`in Remove`);
  }

  public getCompById(companyId: number): Observable<Company> {
    return this.httpClient.get<Company>('http://localhost:8080/Admin/getCompany/' + companyId, {withCredentials: true});
  }

  public get getAllComps(): Observable<Company[]> {
    return this.httpClient.get<Company[]>('http://localhost:8080/Admin/getAllComps', {withCredentials: true});
  }

  // -----------------------Customer--------------------------------------------------------

  public createCustomer(customer: Customer): Observable<Customer> {
    return this.httpClient.post<Customer>('http://localhost:8080/Admin/creatCustomer', customer, {withCredentials: true});
  }

  public updateCustomer(customer: Customer): Observable<Customer> {
    return this.httpClient.put<Customer>('http://localhost:8080/Admin/updateCustomer', customer, {withCredentials: true});
  }

  public removeCustomer(custId: number): Observable<boolean> {
    return this.httpClient.delete<boolean>('http://localhost:8080/Admin/removeCustomer/' + custId, {withCredentials: true});
    alert(`in Remove`);
  }

  public geCustomerById(custId: number): Observable<Customer> {
    return this.httpClient.get<Customer>('http://localhost:8080/Admin/getCustomer/' + custId , {withCredentials: true});
  }

  public get getAllCustomers(): Observable<Customer[]> {
    return this.httpClient.get<Customer[]>('http://localhost:8080/Admin/getAllCustomer', {withCredentials: true});
  }




}
