export class Customer {
  public custId: number;
  public custName: string;
  public password: string;

  constructor(
      custId?: number,
      custName?: string,
      password?: string
      ) {
      this.custId = custId;
      this.custName = custName;
      this.password = password;
  }
}
