export class User {

    public id: number;
    public userName: string;
    public password: string;
    public clientType: ClientType;


    constructor(
        id?: number,
        userName?: string,
        clientType?: ClientType,
        password?: string,
    ) {
        this.id = id;
        this.clientType = clientType;
        this.userName = userName;
        this.password = password;
    };

}

export enum ClientType {
    ADMIN = 'ADMIN',
    COMPANY = 'COMPANY',
    CUSTOMER = 'CUSTOMER'
}
