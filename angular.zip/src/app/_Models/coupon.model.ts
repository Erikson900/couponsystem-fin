export class Coupon {
    public id: number;
    public title: string;
    public amount?: number;
    public price?: number;
    public message: string;
    public startDate?: Date;
    public endDate?: Date;
    public couponType?: CouponType; // CouponType
    public image: string;
    public company?: number;


    constructor(
        id?: number,
        title?: string,
        amount?: number,
        price?: number,
        message?: string,
        startDate?: Date,
        endDate?: Date,
        couponType?: CouponType,
        image?: string,
        company?: number
    ) {
    this.id = id;
    this.title = title;
    this.amount = amount;
    this.price = price;
    this.message = message;
    this.startDate = startDate;
    this.endDate = endDate;
    this.couponType = couponType;
    this.image = image;
    this.company = company;
    }

}

export enum CouponType {
  HEALTH = 'HEALTH',
  FOOD = 'FOOD',
  LIFESTYLE = 'LIFESTYLE',
  SPORTS = 'SPORTS',
  TRAVEL = 'TRAVEL'
}
