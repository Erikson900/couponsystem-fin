import { Component, OnInit, OnChanges } from '@angular/core';
import { ClientType, User } from 'src/app/_Models/user.model';
import { AuthService } from 'src/app/_Service/auth.service';
import { Subscription } from 'rxjs';


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit, OnChanges {

  subscription: Subscription;
  user: User = new User();
  public = true;
  admin = false;
  company = false;
  customer = false;

  constructor(private authService: AuthService) { }

  ngOnInit() {
    this.user = this.authService.getLoggedUser();
    if (this.user.clientType === ClientType.ADMIN && this.user.userName != null) {
      this.public = false;
      this.admin = true;
      this.company = false;
      this.customer = false;
    } else if (this.user.clientType === ClientType.COMPANY && this.user.userName != null ) {
      this.public = false;
      this.admin = false;
      this.company = true;
      this.customer = false;
    } else if (this.user.clientType === ClientType.CUSTOMER && this.user.userName != null ) {
      this.public = false;
      this.admin = false;
      this.company = false;
      this.customer = true;
    } else {
      this.public = true;
      this.admin = false;
      this.company = false;
      this.customer = false;
    }
  };

  ngOnChanges(changes: import("@angular/core").SimpleChanges): void {
    for (let this.user in changes) {
      let change = changes[this.user];
      let curVal  = JSON.stringify(change.currentValue);
      let prevVal = JSON.stringify(change.previousValue);

            console.log(curVal);
            console.log(prevVal);
        }
      };

}
