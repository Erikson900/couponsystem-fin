import { AdminService } from 'src/app/_Service/admin.service';
import { Component, OnInit } from '@angular/core';
import { Company } from 'src/app/_Models/company.model';

@Component({
  selector: 'app-companys-list',
  templateUrl: './companys-list.component.html',
  styleUrls: ['./companys-list.component.css']
})
export class CompanysListComponent implements OnInit {

  company: Company[];

  constructor(private adminService: AdminService) { }

  ngOnInit() {
    const observable = this.adminService.getAllComps;
    observable.subscribe(companies => this.company = companies);
  }

  onEdit(company: Company) {
    this.adminService.startedEdeting.next(company);
  }

  onDelete(compId: number){
    this.adminService.removeComp(compId);
  }

}
