import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-companys-list',
  templateUrl: './companys-list.component.html',
  styleUrls: ['./companys-list.component.css']
})
export class CompanysListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
