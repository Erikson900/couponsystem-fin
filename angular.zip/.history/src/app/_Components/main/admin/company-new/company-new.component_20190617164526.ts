import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-company-new',
  templateUrl: './company-new.component.html',
  styleUrls: ['./company-new.component.css']
})
export class CompanyNewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
