import { AdminService } from './../../../../_Service/admin.service';
import { Company } from 'src/app/_Models/company.model';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-company-new',
  templateUrl: './company-new.component.html',
  styleUrls: ['./company-new.component.css']
})
export class CompanyNewComponent implements OnInit {

  public company: Company = new Company();

  constructor(private adminService: AdminService) { }

  ngOnInit() {
  }

  public createCompany(){
    alert(`
    CompanyName: ${this.company.name}
    CompanyPassword: ${this.company.password}
    CompanyEmail: ${this.company.email}
    `);


    this.adminService.createComp(this.company).subscribe( company => {
      this.company = company;
      console.log(company);}, err => {
        alert(err.massage);
    })
  }

}
