import { Router, ActivatedRoute } from '@angular/router';
import { AdminService } from 'src/app/_Service/admin.service';
import { Component,ViewChild, OnInit } from '@angular/core';
import { Company } from 'src/app/_Models/company.model';
import { NgForm, FormGroup, FormControl, FormArray, Validators } from '@angular/forms';
import { Subscription } from 'rxjs/internal/Subscription';


@Component({
  selector: 'app-company-edit',
  templateUrl: './company-edit.component.html',
  styleUrls: ['./company-edit.component.css']
})
export class CompanyEditComponent implements OnInit {
  @ViewChild('f') CompanyListForm: NgForm;
  subscription: Subscription;
  company: Company = new Company();
  id: number;
  editMode = false;
  companyForm: FormGroup;


  constructor(private adminService: AdminService, private router: Router,private route: ActivatedRoute) { }

  ngOnInit() {
    this.subscription = this.adminService.startedEdeting
    .subscribe(
      (company: Company) => {
        this.company = company;

      }
    );
  }

  onUpdate(company: Company){
    
    alert(`
    CompanyId: ${this.company.id}
    CompanyName: ${this.company.compName}
    CompanyPassword: ${this.company.password}
    CompanyEmail: ${this.company.email}
    `);

    this.adminService.updateComp(this.company).subscribe( company => {
      this.company = company;
      console.log(company);}, err => {
        alert(err.error.massage);
    })
  }

  onSubmit() {}

  onCancel() {
    //this.router.navigate(['../'], { relativeTo: this.route});
  }

}
