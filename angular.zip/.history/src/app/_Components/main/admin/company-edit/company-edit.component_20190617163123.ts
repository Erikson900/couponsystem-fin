import { Component, OnInit } from '@angular/core';
import { Company } from '_Models/company.model';

@Component({
  selector: 'app-company-edit',
  templateUrl: './company-edit.component.html',
  styleUrls: ['./company-edit.component.css']
})
export class CompanyEditComponent implements OnInit {

  company:Company = new Company();

  constructor() { }

  ngOnInit() {
  }

}
