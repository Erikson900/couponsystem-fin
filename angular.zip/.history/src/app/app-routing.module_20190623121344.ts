import { RegisterComponent } from 'src/app/_Components/main/register/register.component';
import { LoginComponent } from './_components/main/login/login.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MainComponent } from './_Components/main/main.component';

const routes: Routes = [
  {path: '', redirectTo: 'main', pathMatch: 'full' },
  {path: '**', redirectTo: 'main' },
  {path: 'main', component: MainComponent },
  {path: 'main', loadChildren: './_Components/main/main.component'},
  {path: 'login', component: LoginComponent},
  //{path: 'regiter', component: RegisterComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
