import { AdminComponent } from './_components/main/admin/admin.component';
import { CouponComponent } from './_components/main/coupon/coupon.component';
import { CustomerComponent } from './_components/main/customer/customer.component';
import { CompanyComponent } from './_components/main/company/company.component';
import { HeaderComponent } from './_components/header/header.component';
import { AllCouponsComponent } from './_components/main/all-coupons/all-coupons.component';
import { ListPerchaseCouponsComponent } from './_components/main/list-perchase-coupons/list-perchase-coupons.component';
import { CustomersListComponent } from './_components/main/admin/customers-list/customers-list.component';
import { CompanysListComponent } from './_components/main/admin/companys-list/companys-list.component';
import { CompanyEditComponent } from './_components/main/admin/company-edit/company-edit.component';
import { CustomerEditComponent } from './_components/main/admin/customer-edit/customer-edit.component';
import { CustomerNewComponent } from './_components/main/admin/customer-new/customer-new.component';
import { CompanyNewComponent } from './_components/main/admin/company-new/company-new.component';
import { LoginComponent } from './_components/main/login/login.component';
import { RegisterComponent } from './_components/main/register/register.component';
import { CouponEditComponent } from './_Components/main/company/coupon-edit/coupon-edit.component';
import { CouponNewComponent } from './_components/main/company/coupon-new/coupon-new.component';
import { PerchasedCouponsComponent } from './_components/main/customer/perchased-coupons/perchased-coupons.component';
import { CustomerCouponComponent } from './_components/main/customer/customer-coupon/customer-coupon.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MainComponent } from './_Components/main/main.component';

const routes: Routes = [
  {path: 'Home', component: ListPerchaseCouponsComponent},
  {path: 'main', component: MainComponent},
  {path: 'login', component: LoginComponent},
  {path: 'register', component: RegisterComponent},
  // -------------Admin---------------------------------------
  {path: 'mainManage', component: AdminComponent},
  {path: 'allCompanise', component: CompanysListComponent},
  {path: 'allCustomers', component: CustomersListComponent},
  // -------------Company---------------------------------------
  {path: 'allCustomers', component: CustomersListComponent},
  {path: 'allCustomers', component: CustomersListComponent},
  // -------------Cutomer---------------------------------------
  {path: 'store', component: CustomersListComponent},
  {path: 'myCoupons', component: CustomersListComponent},




  //{path: 'about', component : AboutComponent},
  //{path: '', redirectTo: '/main', pathMatch: 'full' },
  //{path: '**', redirectTo: '/main', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
