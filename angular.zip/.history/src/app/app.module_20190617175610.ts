import { MainComponent } from './_Components/main/main.component';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AdminComponent } from './_components/main/admin/admin.component';
import { CouponComponent } from './_components/main/coupon/coupon.component';
import { CustomerComponent } from './_components/main/customer/customer.component';
import { CompanyComponent } from './_components/main/company/company.component';
import { HeaderComponent } from './_components/header/header.component';
import { AllCouponsComponent } from './_components/main/all-coupons/all-coupons.component';
import { ListPerchaseCouponsComponent } from './_components/main/list-perchase-coupons/list-perchase-coupons.component';
import { CustomersListComponent } from './_components/main/admin/customers-list/customers-list.component';
import { CompanysListComponent } from './_components/main/admin/companys-list/companys-list.component';
import { CompanyEditComponent } from './_components/main/admin/company-edit/company-edit.component';
import { CustomerEditComponent } from './_components/main/admin/customer-edit/customer-edit.component';
import { CustomerNewComponent } from './_components/main/admin/customer-new/customer-new.component';
import { CompanyNewComponent } from './_components/main/admin/company-new/company-new.component';
import { LoginComponent } from './_components/main/login/login.component';
import { RegisterComponent } from './_components/main/register/register.component';
import { CouponEditComponent } from './_Components/main/company/coupon-edit/coupon-edit.component';


@NgModule({
  declarations: [
    AppComponent,
    MainComponent,
    AdminComponent,
    CouponComponent,
    CustomerComponent,
    CompanyComponent,
    HeaderComponent,
    AllCouponsComponent,
    ListPerchaseCouponsComponent,
    CustomersListComponent,
    CompanysListComponent,
    CompanyEditComponent,
    CustomerEditComponent,
    CustomerNewComponent,
    CompanyNewComponent,
    LoginComponent,
    RegisterComponent,
    CouponEditComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
