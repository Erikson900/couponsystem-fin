import { RegisterComponent } from './_components/main/register/register.component';
import { LoginComponent } from './_components/main/login/login.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MainComponent } from './_Components/main/main.component';

const routes: Routes = [
  {path: 'main', component: MainComponent, children: [
  {path: 'login', component: LoginComponent},
  {path: 'regiter', component: RegisterComponent}
  ]},

  //{path: 'about', component : AboutComponent},
  //{path: '', redirectTo: '/main', pathMatch: 'full' },
  //{path: '**', redirectTo: '/main', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
