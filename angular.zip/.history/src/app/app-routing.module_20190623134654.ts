import { AdminComponent } from './_components/main/admin/admin.component';
import { ListPerchaseCouponsComponent } from './_components/main/list-perchase-coupons/list-perchase-coupons.component';
import { RegisterComponent } from './_components/main/register/register.component';
import { LoginComponent } from './_components/main/login/login.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MainComponent } from './_Components/main/main.component';

const routes: Routes = [
  {path: 'Home', component: ListPerchaseCouponsComponent},
  {path: 'main', component: MainComponent},
  {path: 'login', component: LoginComponent},
  {path: 'register', component: RegisterComponent},
  {path: 'mainManage', component: AdminComponent}

  //{path: 'about', component : AboutComponent},
  //{path: '', redirectTo: '/main', pathMatch: 'full' },
  //{path: '**', redirectTo: '/main', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
